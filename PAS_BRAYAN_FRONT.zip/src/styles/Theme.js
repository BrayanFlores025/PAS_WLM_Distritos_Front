import { createTheme } from '@mui/material/styles';
import { green, purple } from '@mui/material/colors';

const theme = createTheme({
  palette: {
    primary: {
      main: '#1A75CF',
    },
    secondary: {
      main: '#E5722B',
    },
  },
});

export default theme;