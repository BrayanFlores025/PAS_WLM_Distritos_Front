/*import axios from "axios"
const TiendasService = {

    fetchClient: ()=>{
        return axios.post(`localhost/3001/back/fetchTiendas`)
        .then(response => {
            console.log(response.data)
            return response.data})
            .catch(error => {
              //  HandleError.HandleError(error)
            })
        }
    }
    export default TiendasService;*/
   