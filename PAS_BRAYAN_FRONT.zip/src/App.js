import { ThemeProvider } from '@mui/material';
import React, { Fragment, useState} from 'react';
//import { theme } from './styles/theme';
import AppRoutes from './Routes/AppRoutes';
import theme from './styles/Theme';
//import styles from './styles/styles.css'

function App() {
  
  return (
         <Fragment>
      <ThemeProvider theme={theme}>
            <AppRoutes />
      </ThemeProvider>
         </Fragment>

  );
}

export default App;