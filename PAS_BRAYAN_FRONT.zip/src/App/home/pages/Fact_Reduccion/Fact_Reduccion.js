import React, { Fragment } from 'react';
import { Typography, Grid, Button, Divider, TextField } from '@mui/material';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import { Navigate, useNavigate } from 'react-router';
import TableFactReducc from './Components/TableFactReducc';




const Fact_Redduccion = () => {
     
    const style = {
        width: '100%',
        
        bgcolor: '#FFFFFF',
      };

    const navigate = useNavigate();
    
    return(
        <Fragment>  
           
            <Grid container sx={{
                padding: '5% 8%'
            }}>

             <Grid container>
                <Grid item xs={12}>
                 <Typography fontSize='Poppins' variant='h4' color='#1A75CF'><strong>Factor de Redduccion</strong></Typography>
                </Grid>
                 <Grid item xs={9} padding='1% 0%'>
                  <Typography variant='caption'>Lorem ipsum dolor sit amet, consectur adipiscing elit sed do elusmod</Typography>
                 </Grid>
                 <Grid item xs={3} padding='0% 0%'>
                  <Button style={{borderRadius: '16px'}} onClick={() => navigate('/impuestos/addimpuesto')} color='secondary' variant='contained'>+ Añadir nueva reduccion</Button>
                 </Grid>
             </Grid>

             <Grid container item xs={12} marginTop='35px'>
                <Typography>Resultado de búsqueda: 0</Typography>
             </Grid>
             <Grid container item xs={12} marginTop='0px'>
             <List sx={style}>
                
             <Divider sx={{border: '1px solid #4C4C4C', padding: '0 0%'}} variant='middle' />
             </List>
             </Grid>

             <TableFactReducc />
            </Grid>
    
    
    
        </Fragment>
    )
}

export default Fact_Redduccion;

