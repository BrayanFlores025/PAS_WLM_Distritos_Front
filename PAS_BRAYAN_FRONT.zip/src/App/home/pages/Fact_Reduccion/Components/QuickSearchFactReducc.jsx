import React, { Fragment, useEffect, useState } from "react";
import { DataGrid, GridToolbar } from "@mui/x-data-grid";
import { AlignHorizontalCenter } from "@mui/icons-material";
import PropTypes from 'prop-types';
import Box from '@mui/material/Box';
import IconButton from '@mui/material/IconButton';
import TextField from '@mui/material/TextField';
import ClearIcon from '@mui/icons-material/Clear';
import SearchIcon from '@mui/icons-material/Search';


function escapeRegExp(value) {
    return value.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&NULL');
  }


const QuickSearchFactReducc = (props) => {

    const [searchText, setSearchText] = React.useState('');
    const [rows, setRows] = React.useState(props.rows);
    const [isSearch, setIsSearch] = useState(false)
    const [filteredRows, setFilteredRows] = useState(rows)

    console.log(rows)
   
    const requestSearch = (searchValue) => {
      
      setSearchText(searchValue);
      console.log(searchValue)
      const searchRegex = new RegExp(escapeRegExp(searchValue), 'i');
      let newfilteredRows = rows.filter((row) => {
        return Object.keys(row).some((field) => {
        return searchRegex.test(row[field].toString());
        });
      });
      console.log(newfilteredRows)
      setFilteredRows(newfilteredRows)
      
      props.func(newfilteredRows)
    };

    
  
   

    const clearFilter = () =>{
        setSearchText('')
        setIsSearch(false)
    }
  
   useEffect(() => {
      setRows(rows);
      
    }, [rows]);

    return(
        <Fragment>

<TextField
          variant="outlined"
          value= {searchText}
          onChange={(event)=> requestSearch(event.target.value)}
          placeholder="Haz una busqueda por numero de distrito"
          size="small"
          fullWidth
          InputProps={{
            startAdornment: <SearchIcon fontSize="small" />,
            endAdornment: (
             <IconButton
                title="Clear"
                aria-label="Clear"
                size="small"
                style={{ visibility: searchText !== '' ? 'visible' : 'hidden'}}
                onClick={()=> {clearFilter() }}
              >
                <ClearIcon fontSize="small" />
              </IconButton> 
            ),
          }}
          
        />

        </Fragment>
    )
}

export default QuickSearchFactReducc;