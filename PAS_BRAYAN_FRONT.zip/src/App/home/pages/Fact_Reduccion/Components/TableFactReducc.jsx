import * as React from 'react';
import { DataGrid, GridActionsCellItem } from '@mui/x-data-grid';
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import EditIcon from '@mui/icons-material/Edit';
import Switch from '@mui/material/Switch';
import { IconButton, Typography } from '@mui/material';
import { useState } from 'react';
import { useEffect } from 'react';
import QuickSearchFactReducc from './QuickSearchFactReducc';



const TableFactReducc = () => {

   
    
    const [checked, setChecked] = React.useState(true);
    const [rows, setRows] = useState([
        { id: 22750, fri: '0.1', frb: '1', fronterizo: 'Si', Estatus: 'Activo',  },
        { id: 45678, fri: '0.2', frb: '2', fronterizo: 'No', Estatus: 'Inactivo',  },
        { id: 67899, fri: '0.3', frb: '3', fronterizo: 'Si', Estatus: 'Activo', }
      ])
    console.log(rows)

  const handleChange = (event) => {
    setChecked(event.target.checked);
  };

  const pullData = (data) => {
      console.log(data)
      if(data !== rows){
        setRows(data)
      }
  }

    const columns = [
        { field: 'id', headerName: 'ID', flex: 0.3},
        { field: 'fri', headerName: 'Valor FRI', flex: 2.5},
        { field: 'frb', headerName: 'Valor FRB', flex: 2.5},
        { field: 'Estatus', headerName: 'Estatus', flex: 1,
         type: 'actions',
         renderCell: (params) => (
          <FormGroup>
            {console.log(params)}
            {params.row.Estatus === 'Activo' ?
            <FormControlLabel control={<Switch checked />}  label="Activo" />
            :  <FormControlLabel control={<Switch   />}  label="Inactivo" />
        }
          </FormGroup>
         )
      },
      { field: 'Acciones', headerName: 'Acciones', flex: 1,
      type: 'actions',
      renderCell: (params) => (
       <>
       <IconButton onClick={() => window.location.href='http://localhost:3000/distritos/editdistrito'}>
        <EditIcon color='#1A75CF' fontSize='small' />
        </IconButton>
        <Typography variant='p'>Editar</Typography>
       </>
      )
   },
      ];
      


  return (
    <div style={{ height: 600, width: '100%' }}>
        
        <QuickSearchFactReducc rows={rows} columns={columns} func={pullData} />
      <DataGrid
        rows={rows}
        columns={columns}
        pageSize={50} 
      />

    </div>
  );
}

export default TableFactReducc;