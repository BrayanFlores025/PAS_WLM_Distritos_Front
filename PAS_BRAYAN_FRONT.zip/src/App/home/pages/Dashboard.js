import React, { Fragment, useEffect, useState } from "react";
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import { Button, CardActionArea, CardActions } from '@mui/material';

import Navbar from "../components/Navbar";
//import dashboardService from '../../../services/dashboardService'
//import axios from 'axios';
//import ErrorMessage from '../../UX/errorMessage'
const Dashboard = () => {

let numero ='aqui va la grafica'

console.log(numero)
return(
        
        <Fragment>
            <Navbar/>
        </Fragment>

    )
}
export default Dashboard;