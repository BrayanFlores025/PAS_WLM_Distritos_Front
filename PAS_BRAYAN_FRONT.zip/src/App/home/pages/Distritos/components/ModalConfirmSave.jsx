import React, { Fragment } from "react";
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';
import { Grid } from "@mui/material";
import ModalSaveChanges from "./ModalSaveChanges";


const style = {
    position: 'absolute',
    top: '40%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    border: '2px solid #000',
    boxShadow: 24,
    p: 4,
  };

const ModalConfirmSave = () => {

    const [open, setOpen] = React.useState(true);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

    return(
        <Fragment>

<Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
        
           <Grid container>
            <Grid item xs={12}>
               <Typography marginLeft='15%' fontSize='Poppins' variant="h6"><strong>Guardado de información</strong></Typography>
            </Grid>
            <Grid item  xs={12} marginTop='6%' marginLeft='2%'>
                <Typography>Al dar clicken aceptar la siguiente información se guardara
                    y se publicará de la plataforma
                </Typography>
            </Grid>
            <Grid item  xs={5} marginTop='15%' marginLeft='20%'>
                <Button onClick={handleClose}  style={{borderRadius: '19px'}} variant="outlined">Cancelar</Button>
                
            </Grid>
            <Grid item  xs={4} marginTop='15%' >
            <Button onClick={() => <ModalSaveChanges />} style={{borderRadius: '19px'}} fullWidth  variant="contained">Aceptar</Button>
                
            </Grid>
            
           </Grid>
        </Box>
      </Modal>

        </Fragment>
    )
}

export default ModalConfirmSave;