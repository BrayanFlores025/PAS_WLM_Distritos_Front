import * as React from 'react';
import { DataGrid, GridActionsCellItem } from '@mui/x-data-grid';
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import EditIcon from '@mui/icons-material/Edit';
import Switch from '@mui/material/Switch';
import { IconButton, Typography } from '@mui/material';
import QuickSearchDistritos from './QuickSearchDistrtitos';
import { useState } from 'react';
import { useEffect } from 'react';
import ModalChangeEstatus from './ModalChangeEstatus';



const TableDistritos = () => {

   
    
    const [checked, setChecked] = React.useState(true);
    const [rows, setRows] = useState([
        { id: 22750, Estatus: 'Activo',  },
        { id: 45678, Estatus: 'Inactivo',  },
        { id: 67899, Estatus: 'Activo', }
      ])
    console.log(rows)

  const handleChange = (event) => {
    setChecked(event.target.checked);
  };

  const pullData = (data) => {
      console.log(data)
      if(data !== rows){
        setRows(data)
      }
  }

    const columns = [
        { field: 'id', headerName: 'Distrito', flex: 5},
        { field: 'Estatus', headerName: 'Estatus', flex: 1,
         type: 'actions',
         renderCell: (params) => (
          <FormGroup>
            {console.log(params)}
            {params.row.Estatus === 'Activo' ?
            <FormControlLabel control={<Switch checked />}  label="Activo" />
            :  <FormControlLabel control={<Switch onClick={() => <ModalChangeEstatus />}  />}  label="Inactivo" />
        }
          </FormGroup>
         )
      },
      { field: 'Acciones', headerName: 'Acciones', flex: 1,
      type: 'actions',
      renderCell: (params) => (
       <>
       <IconButton onClick={() => window.location.href='http://localhost:3000/distritos/editdistrito'}>
        <EditIcon color='#1A75CF' fontSize='small' />
        </IconButton>
        <Typography variant='p'>Editar</Typography>
       </>
      )
   },
      ];
      


  return (
    <div style={{ height: 600, width: '100%' }}>
        
        <QuickSearchDistritos rows={rows} columns={columns} func={pullData} />
      <DataGrid
        rows={rows}
        columns={columns}
        pageSize={50} 
      />

    </div>
  );
}

export default TableDistritos;