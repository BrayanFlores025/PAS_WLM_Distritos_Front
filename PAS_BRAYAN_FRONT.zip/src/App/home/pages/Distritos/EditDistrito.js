import React, { Fragment, useState } from "react";
import { useNavigate } from "react-router";
import { useForm } from "react-hook-form";

import { Button, Divider, Grid, List, TextField, Typography } from "@mui/material";
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import Alert from '@mui/material/Alert';
import Stack from '@mui/material/Stack';
import ModalConfirmSave from "./components/ModalConfirmSave";

const EditDistrito = () => {

    const style = {
        width: '100%',
        
        bgcolor: '#FFFFFF',
      };

    const navigate = useNavigate();

    const [age, setAge] = React.useState('');
    const [handleOpenModal, setHandleOpenModal] = useState(false)

    const handleChange = (event) => {
      setAge(event.target.value);
    };

    const { register, handleSubmit, watch, formState: { errors } } = useForm();

  const onSubmit = (data) => {
    setHandleOpenModal(true)
    console.log(data)
    };
    

    return(
        <Fragment>
<form onSubmit={handleSubmit(onSubmit)}>
<Grid container sx={{
                padding: '4% 8%'
            }}>

             <Grid container>
                <Grid item xs={12}>
                 <Typography fontSize='Poppins' variant='h4' color='#1A75CF'><strong>Editar Distrito</strong></Typography>
                </Grid>
                 <Grid item xs={9} padding='1% 0%'>
                  <Typography variant='p'>Edita los datos que se solicitan</Typography>
                 </Grid>
                 
                 <Grid item xs={3} padding='0% 0%'>
                  
                 </Grid>
             </Grid>
             {errors.distrtito && 
             <Stack sx={{ width: '100%' }} spacing={2}>
             <Alert severity="error">¡Oh! Los campos marcados con (*) no pueden ir vacios.</Alert>
             </Stack>
             }
             <Grid  item xs={3} marginTop='35px'>
                <Typography variant="p">Distrito*</Typography>
             </Grid>
             <Grid  item xs={8} marginTop='35px' marginLeft='2%'>
                <Typography variant="p">Estatus*</Typography>
             </Grid>
             <Grid  item xs={3} marginTop='5px'>
             <TextField 
              name='distrtito'
              size="middle" 
              fullWidth 
              id="outlined-basic" 
              label="Outlined" 
              variant="outlined"
              {...register("distrtito", { required: true })} 
              />
             </Grid>
             <Grid  item xs={3} marginTop='5px' marginLeft='2%'> <FormControl fullWidth>
        <InputLabel id="demo-simple-select-label">Selecciona un estado</InputLabel>
        <Select
          labelId="demo-simple-select-label"
          id="demo-simple-select"
          value={age}
          label="Age"
          onChange={handleChange}
        >
          <MenuItem disabled value={10}>---</MenuItem>
          <MenuItem value={20}>Activo</MenuItem>
          <MenuItem value={30}>Inactivo</MenuItem>
        </Select>
      </FormControl>
             </Grid>
             <Grid container item xs={12} marginTop='0px'>
           
             </Grid>

             <Grid item container marginTop='23%'>
              <Grid item xs={7.5}></Grid>
              <Grid item xs={2}><Button 
                                 onClick={() => {
                                    navigate(-1)
                                 }}
                                 style={{borderRadius: '19px'}} 
                                 fullWidth  
                                 variant="outlined">Regresar</Button></Grid>
            
             <Grid item xs={2} marginLeft='2%'>
                           <Button 
                           type="submit" 
                           style={{borderRadius: '19px'}} 
                           fullWidth  variant="contained"
                           >Guardar</Button></Grid>
             </Grid>
            </Grid>

            {handleOpenModal ? <ModalConfirmSave /> : null}
    
            </form>
        </Fragment>
    )
}

export default EditDistrito;