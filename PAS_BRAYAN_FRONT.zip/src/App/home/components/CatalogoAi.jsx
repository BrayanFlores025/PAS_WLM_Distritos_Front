import { Button, Typography } from "@mui/material";
import React, { Fragment,useEffect } from "react";
import { DataGrid } from '@mui/x-data-grid';

//import TiendasService from "../../../services/walmartServices";

const CatalogoAi = () => {
    
    //useEffect(()=>{ 
        // TiendasService.fetchClient().then(reponse=>console.log(response))
     //},[])

     const columns = [
        { field: 'id', headerName: 'Pais', width: 70 },
        { field: 'firstName', headerName: 'Compañia', width: 130 },
        { field: 'lastName', headerName: 'Nogocio', width: 130 },
        {
          field: 'age',
          headerName: 'N° de Tiendas',
          type: 'number',
          width: 130,
        },
        {
            flex: 1,
          field: 'fullName',
          headerName: 'Tiendas',
          description: 'This column has a value getter and is not sortable.',
          sortable: false,
          width: 160,
          valueGetter: (params) =>
            `${params.row.firstName || ''} ${params.row.lastName || ''}`,
        },
        { field: 'IPU', headerName: 'IPU', width: 130 },
        { field: 'Estatus', headerName: 'Estatus', width: 130 },
        { field: 'Action', headerName: 'Action', width: 130 },
      ];
      
      const rows = [
        { id: 1, lastName: 'Snow', firstName: 'Jon', age: 35 },
        { id: 2, lastName: 'Lannister', firstName: 'Cersei', age: 42 },
        { id: 3, lastName: 'Lannister', firstName: 'Jaime', age: 45 },
        { id: 4, lastName: 'Stark', firstName: 'Arya', age: 16 },
        { id: 5, lastName: 'Targaryen', firstName: 'Daenerys', age: null },
        { id: 6, lastName: 'Melisandre', firstName: null, age: 150 },
        { id: 7, lastName: 'Clifford', firstName: 'Ferrara', age: 44 },
        { id: 8, lastName: 'Frances', firstName: 'Rossini', age: 36 },
        { id: 9, lastName: 'Roxie', firstName: 'Harvey', age: 65 },
      ];

    return(
        <Fragment>
            
            <div style={{padding: '5% 5% 5% 5%'}}>
            <Button color="error">+ Añadir nueva tienda</Button>
          <Typography variant="h4">Tiendas</Typography>
          <br />
          <div style={{ height: 400, width: '100%' }}>
      <DataGrid
        rows={rows}
        columns={columns}
        pageSize={5}
        rowsPerPageOptions={[5]}
        checkboxSelection
      />
    </div>
            </div>
        </Fragment>
    )
}

export default CatalogoAi;