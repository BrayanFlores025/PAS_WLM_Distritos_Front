import React, { Fragment } from "react";
import { Outlet } from "react-router";
import Navbar from "../../App/home/components/Navbar";

export function Layout () {

    return(
        <Fragment>
            <Navbar />

            <Outlet />
        </Fragment>
    )
}