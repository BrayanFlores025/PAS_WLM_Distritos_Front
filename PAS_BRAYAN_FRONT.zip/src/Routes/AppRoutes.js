import React, { Fragment, useState } from "react";
import Dashboard from "../App/home/pages/Dashboard";
import {
    BrowserRouter as Router,
    Route,
    BrowserRouter,
    Routes,
  } from "react-router-dom";
import Navbar from "../App/home/components/Navbar";
import Distritos from "../App/home/pages/Distritos/Distritos";
import { Layout } from "./Layouts/Layout";
import AddNewDistrito from "../App/home/pages/Distritos/AddNewDistrito";
import EditDistrito from "../App/home/pages/Distritos/EditDistrito";
import Impuestos from "../App/home/pages/Impuestos/Impuestos";
import AddNewImpuesto from "../App/home/pages/Impuestos/AddNewImpuesto";
import Fact_Redduccion from "../App/home/pages/Fact_Reduccion/Fact_Reduccion";

const AppRoutes = () => {


    return(
        <Fragment>

      <BrowserRouter>
          <Routes>
           
           
                 <Route path='/' element={<Layout/>}>
                  <Route path='/distritos' element={<Distritos />} />
                  <Route path="/distritos/adddistrito" element={<AddNewDistrito />} />
                  <Route path="/distritos/editdistrito" element={<EditDistrito />} />
                  <Route path="/impuestos" element={<Impuestos />} />
                  <Route path="/impuestos/addimpuesto" element={<AddNewImpuesto />} />
                  <Route path="/fact_reduccion" element={<Fact_Redduccion />} />
                  </Route>
          </Routes>
      </BrowserRouter> 
                
        </Fragment>
            
    )
}

export default AppRoutes;